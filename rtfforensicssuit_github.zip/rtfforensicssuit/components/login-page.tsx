"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  Lock,
  AlertCircle,
  Monitor,
  Shield,
  Search,
  Activity,
  ShieldCheck,
  User,
  Settings2,
  ExternalLink,
} from "lucide-react"
import Logo from "@/components/logo"
import ThanaSelector from "@/components/thana-selector"
import { getTotalThanaCount } from "@/lib/bangladesh-thanas"

export default function LoginPage() {
  const [selectedThana, setSelectedThana] = useState("")
  const [thanaDetails, setThanaDetails] = useState({ division: "", district: "", thana: "" })
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { login, adminLogin } = useAuth()

  const [showAdminModal, setShowAdminModal] = useState(false)
  const [adminUsername, setAdminUsername] = useState("")
  const [adminPassword, setAdminPassword] = useState("")
  const [adminError, setAdminError] = useState("")
  const [isAdminLoading, setIsAdminLoading] = useState(false)

  const handleThanaChange = (value: string, details: { division: string; district: string; thana: string }) => {
    setSelectedThana(value)
    setThanaDetails(details)
    setError("")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!selectedThana) {
      setError("Please select a Police Station (Thana)")
      return
    }

    if (!password) {
      setError("Please enter your password")
      return
    }

    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 600))

    const success = login(selectedThana, password, thanaDetails)
    if (!success) {
      setError("Invalid credentials. Please try again.")
    }
    setIsLoading(false)
  }

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setAdminError("")

    if (!adminUsername || !adminPassword) {
      setAdminError("Please enter both username and password")
      return
    }

    setIsAdminLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 600))

    const success = adminLogin(adminUsername, adminPassword)
    if (!success) {
      setAdminError("Invalid administrator credentials")
    } else {
      setShowAdminModal(false)
    }
    setIsAdminLoading(false)
  }

  const totalThanas = getTotalThanaCount()

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left side - Branding panel */}
      <div className="hidden lg:flex lg:flex-1 relative overflow-hidden flex-col justify-between p-12">
        {/* Background gradient effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-950/50 via-background to-blue-950/30" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />

        <div className="relative z-10">
          <Logo size="xl" />
          <p className="mt-8 text-lg text-muted-foreground max-w-lg leading-relaxed">
            Professional telecom forensics analysis platform for law enforcement and investigation agencies.
          </p>

          {/* Feature highlights */}
          <div className="mt-10 flex items-center gap-6">
            <div className="flex items-center gap-2 text-sm text-cyan-400">
              <Shield className="w-4 h-4" />
              <span>Secure Analysis</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-cyan-400">
              <Search className="w-4 h-4" />
              <span>Deep Insights</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-cyan-400">
              <Activity className="w-4 h-4" />
              <span>Real-time Processing</span>
            </div>
          </div>
        </div>

        <div className="relative z-10 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/20 backdrop-blur-sm">
              <h3 className="font-semibold text-sm text-cyan-300">CDR Analysis</h3>
              <p className="text-xs text-muted-foreground mt-1">Call detail record processing</p>
            </div>
            <div className="p-4 rounded-xl bg-blue-950/30 border border-blue-500/20 backdrop-blur-sm">
              <h3 className="font-semibold text-sm text-blue-300">Tower Dump</h3>
              <p className="text-xs text-muted-foreground mt-1">Cell tower data analysis</p>
            </div>
            <div className="p-4 rounded-xl bg-blue-950/30 border border-blue-500/20 backdrop-blur-sm">
              <h3 className="font-semibold text-sm text-blue-300">GEO Intelligence</h3>
              <p className="text-xs text-muted-foreground mt-1">Location-based mapping</p>
            </div>
            <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/20 backdrop-blur-sm">
              <h3 className="font-semibold text-sm text-cyan-300">Link Analysis</h3>
              <p className="text-xs text-muted-foreground mt-1">Communication patterns</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Monitor className="w-4 h-4" />
              <span>Optimized for desktop use</span>
            </div>
            <div className="h-3 w-px bg-border" />
            <div className="text-xs text-cyan-400">{totalThanas}+ Police Stations Connected</div>
          </div>
        </div>

        <p className="relative z-10 text-xs text-muted-foreground">
          Version 2.0 | Developed by <span className="text-cyan-400">Rifat Ahmed</span>
        </p>
      </div>

      {/* Right side - Login form */}
      <div className="flex-1 flex items-center justify-center p-8 border-l border-border bg-card/50">
        <div className="w-full max-w-md space-y-8">
          {/* Mobile logo */}
          <div className="lg:hidden text-center">
            <Logo size="lg" className="justify-center" />
          </div>

          <Card className="border-cyan-500/20 bg-card/80 backdrop-blur-sm shadow-2xl shadow-cyan-500/5">
            <CardHeader className="space-y-1 pb-6">
              <CardTitle className="text-2xl text-center">Welcome Back</CardTitle>
              <CardDescription className="text-center">
                Select your Police Station and enter credentials
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-5">
                {error && (
                  <div className="flex items-center gap-2 p-3 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-lg">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    {error}
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="thana" className="text-sm font-medium">
                    Police Station (Thana)
                  </Label>
                  <ThanaSelector
                    value={selectedThana}
                    onChange={handleThanaChange}
                    placeholder="Select your Police Station"
                  />
                  {thanaDetails.division && (
                    <p className="text-xs text-muted-foreground mt-1">
                      {thanaDetails.district} District, {thanaDetails.division}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium">
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 h-11 bg-secondary/50 border-border focus:border-cyan-500/50 focus:ring-cyan-500/20"
                      required
                      autoComplete="current-password"
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full h-11 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-medium shadow-lg shadow-cyan-500/20"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Authenticating...
                    </span>
                  ) : (
                    "Sign In"
                  )}
                </Button>
              </form>

              <div className="mt-6 pt-6 border-t border-border space-y-3">
                <p className="text-xs text-center text-muted-foreground mb-3">Administrator Access</p>

                <Button
                  variant="outline"
                  className="w-full gap-2 bg-transparent border-amber-500/30 hover:border-amber-500/50 hover:bg-amber-500/10 text-amber-400"
                  onClick={() => setShowAdminModal(true)}
                >
                  <ShieldCheck className="w-4 h-4" />
                  Admin Login
                </Button>

                <Link href="/control-panel" className="block">
                  <Button
                    variant="outline"
                    className="w-full gap-2 bg-transparent border-cyan-500/30 hover:border-cyan-500/50 hover:bg-cyan-500/10 text-cyan-400"
                  >
                    <Settings2 className="w-4 h-4" />
                    System Control Panel
                    <ExternalLink className="w-3 h-3 ml-auto opacity-50" />
                  </Button>
                </Link>
              </div>
              {/* End of change */}
            </CardContent>
          </Card>

          <p className="text-center text-xs text-muted-foreground lg:hidden">
            Version 2.0 | Developed by <span className="text-cyan-400">Rifat Ahmed</span>
          </p>
        </div>
      </div>

      <Dialog open={showAdminModal} onOpenChange={setShowAdminModal}>
        <DialogContent className="sm:max-w-md border-amber-500/20 bg-card">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-400">
              <ShieldCheck className="w-5 h-5" />
              Administrator Login
            </DialogTitle>
            <DialogDescription>Access restricted to authorized system administrators only.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAdminLogin} className="space-y-4 mt-4">
            {adminError && (
              <div className="flex items-center gap-2 p-3 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-lg">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {adminError}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="admin-username" className="text-sm font-medium">
                Admin Username
              </Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="admin-username"
                  type="text"
                  placeholder="Enter admin username"
                  value={adminUsername}
                  onChange={(e) => setAdminUsername(e.target.value)}
                  className="pl-10 h-11 bg-secondary/50 border-border focus:border-amber-500/50"
                  autoComplete="username"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="admin-password" className="text-sm font-medium">
                Admin Password
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="admin-password"
                  type="password"
                  placeholder="Enter admin password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="pl-10 h-11 bg-secondary/50 border-border focus:border-amber-500/50"
                  autoComplete="current-password"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <Button
                type="button"
                variant="outline"
                className="flex-1 bg-transparent"
                onClick={() => {
                  setShowAdminModal(false)
                  setAdminUsername("")
                  setAdminPassword("")
                  setAdminError("")
                }}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white"
                disabled={isAdminLoading}
              >
                {isAdminLoading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Verifying...
                  </span>
                ) : (
                  "Login as Admin"
                )}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
