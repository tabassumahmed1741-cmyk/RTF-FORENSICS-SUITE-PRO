"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import Sidebar from "@/components/sidebar"
import CDRAnalyzer from "@/components/modules/cdr-analyzer"
import TowerDumpAnalyzer from "@/components/modules/tower-dump-analyzer"
import DriveTestAnalyzer from "@/components/modules/drive-test-analyzer"
import MutualAnalyzer from "@/components/modules/mutual-analyzer"
import GeoIntelligence from "@/components/modules/geo-intelligence"
import ReportingEngine from "@/components/modules/reporting-engine"
import DashboardHome from "@/components/dashboard-home"
import AdminDashboard from "@/components/admin/admin-dashboard"
import PoliceStationManagement from "@/components/admin/police-station-management"
import UserAccessControl from "@/components/admin/user-access-control"
import ToolConfiguration from "@/components/admin/tool-configuration"
import DataMappingRules from "@/components/admin/data-mapping-rules"
import SystemLogs from "@/components/admin/system-logs"
import SecuritySettings from "@/components/admin/security-settings"
import BackupRestore from "@/components/admin/backup-restore"
import CaseManagement from "@/components/modules/case-management"
import UserProfile from "@/components/modules/user-profile"

export type ModuleType =
  | "home"
  | "cdr"
  | "tower"
  | "drive"
  | "mutual"
  | "geo"
  | "reports"
  | "case"
  | "profile"
  // Admin modules
  | "police-stations"
  | "user-access"
  | "tool-config"
  | "data-mapping"
  | "system-logs"
  | "security"
  | "backup"

export default function Dashboard() {
  const [activeModule, setActiveModule] = useState<ModuleType>("home")
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const { isAdmin } = useAuth()

  const renderModule = () => {
    if (isAdmin) {
      switch (activeModule) {
        case "police-stations":
          return <PoliceStationManagement />
        case "user-access":
          return <UserAccessControl />
        case "tool-config":
          return <ToolConfiguration />
        case "data-mapping":
          return <DataMappingRules />
        case "system-logs":
          return <SystemLogs />
        case "security":
          return <SecuritySettings />
        case "backup":
          return <BackupRestore />
        default:
          return <AdminDashboard onSelectModule={setActiveModule} />
      }
    }

    // Police station user modules
    switch (activeModule) {
      case "cdr":
        return <CDRAnalyzer />
      case "tower":
        return <TowerDumpAnalyzer />
      case "drive":
        return <DriveTestAnalyzer />
      case "mutual":
        return <MutualAnalyzer />
      case "geo":
        return <GeoIntelligence />
      case "reports":
        return <ReportingEngine />
      case "case":
        return <CaseManagement />
      case "profile":
        return <UserProfile />
      default:
        return <DashboardHome onSelectModule={setActiveModule} />
    }
  }

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar
        activeModule={activeModule}
        onSelectModule={setActiveModule}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />
      <main className={`flex-1 transition-all duration-300 min-h-screen ${sidebarCollapsed ? "ml-[72px]" : "ml-72"}`}>
        {renderModule()}
      </main>
    </div>
  )
}
