"use client"

import { useAuth } from "@/lib/auth-context"
import { useDataStore } from "@/lib/data-store"
import type { ModuleType } from "@/components/dashboard"
import { cn } from "@/lib/utils"
import Logo from "@/components/logo"
import {
  PhoneCall,
  Radio,
  Route,
  Users,
  Map,
  FileText,
  LogOut,
  ChevronLeft,
  ChevronRight,
  LayoutDashboard,
  Settings,
  Database,
  MapPin,
  Building2,
  ShieldCheck,
  UserCog,
  Server,
  ClipboardList,
  Lock,
  HardDrive,
  Briefcase,
  User,
} from "lucide-react"

interface SidebarProps {
  activeModule: ModuleType
  onSelectModule: (module: ModuleType) => void
  collapsed: boolean
  onToggleCollapse: () => void
}

const policeStationModules = [
  { id: "home" as ModuleType, label: "Dashboard", icon: LayoutDashboard, description: "Overview & statistics" },
  { id: "cdr" as ModuleType, label: "CDR Analyzer", icon: PhoneCall, description: "Call detail records" },
  { id: "tower" as ModuleType, label: "Tower Dump", icon: Radio, description: "Cell tower analysis" },
  { id: "drive" as ModuleType, label: "Road Map", icon: Route, description: "Route analysis" },
  { id: "mutual" as ModuleType, label: "Mutual Connection", icon: Users, description: "Link analysis" },
  { id: "geo" as ModuleType, label: "GEO Intelligence", icon: Map, description: "Map visualization" },
  { id: "reports" as ModuleType, label: "Report Generate", icon: FileText, description: "Generate reports" },
  { id: "case" as ModuleType, label: "Case Management", icon: Briefcase, description: "Manage cases" },
  { id: "profile" as ModuleType, label: "Profile", icon: User, description: "User profile" },
]

const adminModules = [
  { id: "home" as ModuleType, label: "Admin Dashboard", icon: LayoutDashboard, description: "System overview" },
  { id: "police-stations" as ModuleType, label: "Police Stations", icon: Building2, description: "Station management" },
  { id: "user-access" as ModuleType, label: "User Access", icon: UserCog, description: "Access control" },
  { id: "tool-config" as ModuleType, label: "Tool Configuration", icon: Settings, description: "Configure tools" },
  { id: "data-mapping" as ModuleType, label: "Data Mapping", icon: Database, description: "Mapping rules" },
  { id: "system-logs" as ModuleType, label: "System Logs", icon: ClipboardList, description: "Audit trail" },
  { id: "security" as ModuleType, label: "Security Settings", icon: Lock, description: "Security config" },
  { id: "backup" as ModuleType, label: "Backup & Restore", icon: HardDrive, description: "Data backup" },
]

export default function Sidebar({ activeModule, onSelectModule, collapsed, onToggleCollapse }: SidebarProps) {
  const { user, logout, isAdmin } = useAuth()
  const { stats } = useDataStore()

  const modules = isAdmin ? adminModules : policeStationModules

  return (
    <aside
      className={cn(
        "fixed left-0 top-0 h-screen bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 z-50",
        collapsed ? "w-[72px]" : "w-72",
      )}
    >
      <div className="p-4 border-b border-sidebar-border relative">
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent" />
        {collapsed ? <Logo size="sm" showText={false} className="mx-auto" /> : <Logo size="md" />}
      </div>

      <button
        onClick={onToggleCollapse}
        className="absolute -right-3 top-20 w-6 h-6 bg-sidebar border border-cyan-500/30 rounded-full flex items-center justify-center hover:bg-cyan-500/10 hover:border-cyan-500/50 transition-colors shadow-sm"
        title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
      >
        {collapsed ? (
          <ChevronRight className="w-3 h-3 text-cyan-400" />
        ) : (
          <ChevronLeft className="w-3 h-3 text-cyan-400" />
        )}
      </button>

      {!collapsed && (
        <div className="px-4 pt-3">
          <div
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2",
              isAdmin
                ? "bg-amber-500/10 border border-amber-500/30 text-amber-400"
                : "bg-cyan-500/10 border border-cyan-500/30 text-cyan-400",
            )}
          >
            {isAdmin ? <ShieldCheck className="w-3.5 h-3.5" /> : <MapPin className="w-3.5 h-3.5" />}
            {isAdmin ? "Administrator Mode" : "Operational Mode"}
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {!collapsed && (
          <p
            className={cn(
              "px-3 py-2 text-xs font-medium uppercase tracking-wider",
              isAdmin ? "text-amber-400/70" : "text-cyan-400/70",
            )}
          >
            {isAdmin ? "Admin Modules" : "Analysis Modules"}
          </p>
        )}
        {modules.map((module) => {
          const Icon = module.icon
          const isActive = activeModule === module.id

          return (
            <button
              key={module.id}
              onClick={() => onSelectModule(module.id)}
              title={collapsed ? module.label : undefined}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm group",
                isActive
                  ? isAdmin
                    ? "bg-gradient-to-r from-amber-500/15 to-orange-500/10 text-amber-300 border border-amber-500/30"
                    : "bg-gradient-to-r from-cyan-500/15 to-blue-500/10 text-cyan-300 border border-cyan-500/30"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary",
              )}
            >
              <Icon className={cn("w-5 h-5 shrink-0", isActive && (isAdmin ? "text-amber-400" : "text-cyan-400"))} />
              {!collapsed && (
                <div className="flex-1 text-left">
                  <span className="block font-medium">{module.label}</span>
                  <span className="block text-xs text-muted-foreground group-hover:text-muted-foreground">
                    {module.description}
                  </span>
                </div>
              )}
            </button>
          )
        })}
      </nav>

      {/* Session stats - only for police station users */}
      {!collapsed && !isAdmin && stats.totalSessions > 0 && (
        <div className="p-3 border-t border-sidebar-border">
          <div className="p-3 rounded-lg bg-cyan-950/20 border border-cyan-500/10">
            <div className="flex items-center gap-2 text-xs text-cyan-400/70 mb-2">
              <Database className="w-3 h-3" />
              <span>Session Data</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <p className="text-foreground font-medium">{stats.totalSessions}</p>
                <p className="text-muted-foreground">Sessions</p>
              </div>
              <div>
                <p className="text-foreground font-medium">{stats.totalRecordsProcessed.toLocaleString()}</p>
                <p className="text-muted-foreground">Records</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {!collapsed && isAdmin && (
        <div className="p-3 border-t border-sidebar-border">
          <div className="p-3 rounded-lg bg-amber-950/20 border border-amber-500/10">
            <div className="flex items-center gap-2 text-xs text-amber-400/70 mb-2">
              <Server className="w-3 h-3" />
              <span>System Status</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <p className="text-foreground font-medium">Active</p>
                <p className="text-muted-foreground">Status</p>
              </div>
              <div>
                <p className="text-foreground font-medium">v2.0</p>
                <p className="text-muted-foreground">Version</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* User section */}
      <div className="p-3 border-t border-sidebar-border space-y-2">
        {!collapsed && (
          <div
            className={cn(
              "px-3 py-2 rounded-lg",
              isAdmin ? "bg-amber-950/20 border border-amber-500/10" : "bg-cyan-950/20 border border-cyan-500/10",
            )}
          >
            {isAdmin ? (
              // Admin user display
              <div className="flex items-center gap-2 mb-1">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <p className="text-sm font-medium text-foreground truncate">{user?.username}</p>
              </div>
            ) : (
              // Police station user display
              <>
                <div className="flex items-center gap-2 mb-1">
                  <MapPin className="w-4 h-4 text-cyan-400" />
                  <p className="text-sm font-medium text-foreground truncate">
                    {user?.thanaDetails?.thana ? `${user.thanaDetails.thana} PS` : user?.username}
                  </p>
                </div>
                {user?.thanaDetails?.district && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Building2 className="w-3 h-3" />
                    <span className="truncate">
                      {user.thanaDetails.district}, {user.thanaDetails.division?.replace(" Division", "")}
                    </span>
                  </div>
                )}
              </>
            )}
            <p className={cn("text-xs mt-1", isAdmin ? "text-amber-400/70" : "text-cyan-400/70")}>
              {user?.displayRole}
            </p>
          </div>
        )}

        {collapsed && (
          <div className="flex justify-center py-2" title={user?.username}>
            <div
              className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center border",
                isAdmin ? "bg-amber-500/20 border-amber-500/30" : "bg-cyan-500/20 border-cyan-500/30",
              )}
            >
              {isAdmin ? (
                <ShieldCheck className="w-4 h-4 text-amber-400" />
              ) : (
                <MapPin className="w-4 h-4 text-cyan-400" />
              )}
            </div>
          </div>
        )}

        {!collapsed && !isAdmin && (
          <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-all text-sm">
            <Settings className="w-5 h-5 shrink-0" />
            <span>Settings</span>
          </button>
        )}

        <button
          onClick={logout}
          title={collapsed ? "Sign Out" : undefined}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all text-sm"
        >
          <LogOut className="w-5 h-5 shrink-0" />
          {!collapsed && <span>Sign Out</span>}
        </button>
      </div>
    </aside>
  )
}
