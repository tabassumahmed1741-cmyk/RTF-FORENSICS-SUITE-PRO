"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Briefcase, Search, Plus, FolderOpen, Clock, User, Calendar } from "lucide-react"

interface Case {
  id: string
  caseNumber: string
  title: string
  status: "active" | "pending" | "closed"
  createdAt: string
  lastModified: string
  assignedTo: string
  analysisCount: number
}

export default function CaseManagement() {
  const [searchQuery, setSearchQuery] = useState("")
  const [cases] = useState<Case[]>([
    {
      id: "1",
      caseNumber: "RTF-2024-001",
      title: "Mobile Fraud Investigation",
      status: "active",
      createdAt: "2024-01-10",
      lastModified: "2024-01-15",
      assignedTo: "Gulshan PS",
      analysisCount: 5,
    },
    {
      id: "2",
      caseNumber: "RTF-2024-002",
      title: "Communication Pattern Analysis",
      status: "pending",
      createdAt: "2024-01-12",
      lastModified: "2024-01-14",
      assignedTo: "Adabor PS",
      analysisCount: 3,
    },
    {
      id: "3",
      caseNumber: "RTF-2024-003",
      title: "Tower Dump Analysis - Dhaka",
      status: "closed",
      createdAt: "2024-01-05",
      lastModified: "2024-01-13",
      assignedTo: "Motijheel PS",
      analysisCount: 8,
    },
  ])

  return (
    <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <span className="w-1.5 h-6 bg-gradient-to-b from-cyan-500 to-blue-500 rounded-full" />
            Case Management
          </h1>
          <p className="text-muted-foreground mt-1">Manage and organize investigation cases</p>
        </div>
        <Button className="gap-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500">
          <Plus className="w-4 h-4" />
          New Case
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Cases</p>
                <p className="text-2xl font-bold text-foreground">{cases.length}</p>
              </div>
              <Briefcase className="w-8 h-8 text-cyan-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active</p>
                <p className="text-2xl font-bold text-emerald-400">
                  {cases.filter((c) => c.status === "active").length}
                </p>
              </div>
              <FolderOpen className="w-8 h-8 text-emerald-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending</p>
                <p className="text-2xl font-bold text-amber-400">
                  {cases.filter((c) => c.status === "pending").length}
                </p>
              </div>
              <Clock className="w-8 h-8 text-amber-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Closed</p>
                <p className="text-2xl font-bold text-muted-foreground">
                  {cases.filter((c) => c.status === "closed").length}
                </p>
              </div>
              <Briefcase className="w-8 h-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search cases..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9 bg-secondary border-border focus:border-cyan-500/50"
        />
      </div>

      {/* Cases List */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base">Cases</CardTitle>
          <CardDescription>All investigation cases</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {cases.map((caseItem) => (
              <div
                key={caseItem.id}
                className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                    <Briefcase className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{caseItem.title}</p>
                      <Badge
                        variant="outline"
                        className={
                          caseItem.status === "active"
                            ? "border-emerald-500/50 text-emerald-400"
                            : caseItem.status === "pending"
                              ? "border-amber-500/50 text-amber-400"
                              : "border-muted-foreground/50"
                        }
                      >
                        {caseItem.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{caseItem.caseNumber}</p>
                  </div>
                </div>
                <div className="flex items-center gap-6 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <User className="w-4 h-4" />
                    <span>{caseItem.assignedTo}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <span>{caseItem.lastModified}</span>
                  </div>
                  <Badge variant="secondary">{caseItem.analysisCount} analyses</Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
