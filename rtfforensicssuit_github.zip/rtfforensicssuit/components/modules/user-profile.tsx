"use client"

import { useAuth } from "@/lib/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { User, MapPin, Building2, Clock, Key, Save } from "lucide-react"

export default function UserProfile() {
  const { user } = useAuth()

  return (
    <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <span className="w-1.5 h-6 bg-gradient-to-b from-cyan-500 to-blue-500 rounded-full" />
            User Profile
          </h1>
          <p className="text-muted-foreground mt-1">View and manage your account settings</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Profile Info */}
        <Card className="bg-card border-cyan-500/20 lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <User className="w-4 h-4 text-cyan-400" />
              Account Information
            </CardTitle>
            <CardDescription>Your account details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4 p-4 rounded-lg bg-secondary/30">
              <div className="w-16 h-16 rounded-full bg-cyan-500/20 flex items-center justify-center">
                <MapPin className="w-8 h-8 text-cyan-400" />
              </div>
              <div>
                <p className="text-lg font-medium">
                  {user?.thanaDetails?.thana ? `${user.thanaDetails.thana} Police Station` : user?.username}
                </p>
                <p className="text-sm text-muted-foreground">{user?.displayRole}</p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Police Station</Label>
                <Input
                  value={user?.thanaDetails?.thana || user?.username || ""}
                  disabled
                  className="bg-secondary border-border"
                />
              </div>
              <div className="space-y-2">
                <Label>District</Label>
                <Input value={user?.thanaDetails?.district || "N/A"} disabled className="bg-secondary border-border" />
              </div>
              <div className="space-y-2">
                <Label>Division</Label>
                <Input value={user?.thanaDetails?.division || "N/A"} disabled className="bg-secondary border-border" />
              </div>
              <div className="space-y-2">
                <Label>Role</Label>
                <Input value={user?.displayRole || ""} disabled className="bg-secondary border-border" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Session Info */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              Session
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground">Login Time</p>
              <p className="text-sm font-medium">
                {user?.loginTime ? new Date(user.loginTime).toLocaleString() : "N/A"}
              </p>
            </div>
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground">Session Duration</p>
              <p className="text-sm font-medium">
                {user?.loginTime
                  ? Math.round((Date.now() - new Date(user.loginTime).getTime()) / 60000) + " minutes"
                  : "N/A"}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Change Password */}
        <Card className="bg-card border-border lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Key className="w-4 h-4 text-cyan-400" />
              Change Password
            </CardTitle>
            <CardDescription>Update your account password</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Current Password</Label>
                <Input type="password" className="bg-secondary border-border" />
              </div>
              <div />
              <div className="space-y-2">
                <Label>New Password</Label>
                <Input type="password" className="bg-secondary border-border" />
              </div>
              <div className="space-y-2">
                <Label>Confirm New Password</Label>
                <Input type="password" className="bg-secondary border-border" />
              </div>
            </div>
            <Button className="gap-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500">
              <Save className="w-4 h-4" />
              Update Password
            </Button>
          </CardContent>
        </Card>

        {/* Location Info */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Building2 className="w-4 h-4 text-cyan-400" />
              Station Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Full Address</p>
              <p className="text-sm">
                {user?.thanaDetails?.thana} Police Station, {user?.thanaDetails?.district},{" "}
                {user?.thanaDetails?.division}
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Contact</p>
              <p className="text-sm text-muted-foreground">Contact admin for details</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
