"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { ModuleType } from "@/components/dashboard"
import {
  Building2,
  Users,
  Activity,
  Database,
  Shield,
  Clock,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Server,
  HardDrive,
} from "lucide-react"

interface AdminDashboardProps {
  onSelectModule: (module: ModuleType) => void
}

interface SystemStats {
  totalPoliceStations: number
  activeUsers: number
  totalAnalysisSessions: number
  totalRecordsProcessed: number
  systemUptime: string
  lastBackup: string
  securityAlerts: number
  pendingActions: number
}

interface RecentActivity {
  id: string
  type: string
  user: string
  action: string
  timestamp: string
  status: "success" | "warning" | "error"
}

export default function AdminDashboard({ onSelectModule }: AdminDashboardProps) {
  const [stats, setStats] = useState<SystemStats>({
    totalPoliceStations: 654,
    activeUsers: 127,
    totalAnalysisSessions: 2847,
    totalRecordsProcessed: 15420000,
    systemUptime: "99.9%",
    lastBackup: "2 hours ago",
    securityAlerts: 0,
    pendingActions: 3,
  })

  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([])

  useEffect(() => {
    // Load login logs
    const loginLogs = JSON.parse(localStorage.getItem("rtf_login_logs") || "[]")
    const adminLogs = JSON.parse(localStorage.getItem("rtf_admin_logs") || "[]")
    const allLogs = [...loginLogs, ...adminLogs]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10)
      .map((log, index) => ({
        id: `log-${index}`,
        type: log.role === "administrator" ? "Admin Login" : "User Login",
        user: log.thana || log.username || "Unknown",
        action: log.success ? "Successful login" : "Failed login attempt",
        timestamp: new Date(log.timestamp).toLocaleString(),
        status: log.success ? ("success" as const) : ("warning" as const),
      }))

    setRecentActivity(allLogs)
  }, [])

  const quickActions = [
    { label: "Police Stations", icon: Building2, module: "police-stations" as ModuleType, color: "text-cyan-400" },
    { label: "User Access", icon: Users, module: "user-access" as ModuleType, color: "text-blue-400" },
    { label: "System Logs", icon: Activity, module: "system-logs" as ModuleType, color: "text-teal-400" },
    { label: "Security", icon: Shield, module: "security" as ModuleType, color: "text-amber-400" },
  ]

  const statCards = [
    {
      label: "Police Stations",
      value: stats.totalPoliceStations.toLocaleString(),
      icon: Building2,
      color: "text-cyan-400",
      bgColor: "bg-cyan-500/10",
    },
    {
      label: "Active Users",
      value: stats.activeUsers.toLocaleString(),
      icon: Users,
      color: "text-blue-400",
      bgColor: "bg-blue-500/10",
    },
    {
      label: "Analysis Sessions",
      value: stats.totalAnalysisSessions.toLocaleString(),
      icon: Database,
      color: "text-teal-400",
      bgColor: "bg-teal-500/10",
    },
    {
      label: "Records Processed",
      value: (stats.totalRecordsProcessed / 1000000).toFixed(1) + "M",
      icon: TrendingUp,
      color: "text-emerald-400",
      bgColor: "bg-emerald-500/10",
    },
  ]

  return (
    <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <span className="w-1.5 h-6 bg-gradient-to-b from-amber-500 to-orange-500 rounded-full" />
            Administrator Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">System overview and management controls</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-sm text-emerald-400">System Online</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.label} className="bg-card border-border hover:border-amber-500/30 transition-colors">
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                  </div>
                  <div className={`w-11 h-11 ${stat.bgColor} rounded-xl flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* System Health & Quick Actions */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* System Health */}
        <Card className="bg-card border-amber-500/20">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Server className="w-4 h-4 text-amber-400" />
              System Health
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">System Uptime</span>
              <span className="text-sm font-medium text-emerald-400">{stats.systemUptime}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Last Backup</span>
              <span className="text-sm font-medium">{stats.lastBackup}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Security Alerts</span>
              <span className={`text-sm font-medium ${stats.securityAlerts > 0 ? "text-red-400" : "text-emerald-400"}`}>
                {stats.securityAlerts}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Pending Actions</span>
              <span
                className={`text-sm font-medium ${stats.pendingActions > 0 ? "text-amber-400" : "text-emerald-400"}`}
              >
                {stats.pendingActions}
              </span>
            </div>
            <div className="pt-2">
              <Button
                variant="outline"
                className="w-full gap-2 bg-transparent border-amber-500/30 hover:border-amber-500/50"
                onClick={() => onSelectModule("backup")}
              >
                <HardDrive className="w-4 h-4" />
                Create Backup
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="bg-card border-border lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Quick Actions</CardTitle>
            <CardDescription>Access frequently used admin functions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {quickActions.map((action) => {
                const Icon = action.icon
                return (
                  <button
                    key={action.label}
                    onClick={() => onSelectModule(action.module)}
                    className="flex items-center gap-3 p-4 rounded-lg bg-secondary/50 hover:bg-secondary border border-border hover:border-amber-500/30 transition-all text-left"
                  >
                    <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                      <Icon className={`w-5 h-5 ${action.color}`} />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{action.label}</p>
                      <p className="text-xs text-muted-foreground">Manage settings</p>
                    </div>
                  </button>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            Recent Activity
          </CardTitle>
          <CardDescription>Latest system events and user actions</CardDescription>
        </CardHeader>
        <CardContent>
          {recentActivity.length > 0 ? (
            <div className="space-y-3">
              {recentActivity.map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-center justify-between py-3 px-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {activity.status === "success" ? (
                      <CheckCircle className="w-4 h-4 text-emerald-400" />
                    ) : activity.status === "warning" ? (
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-red-400" />
                    )}
                    <div>
                      <p className="text-sm font-medium">{activity.action}</p>
                      <p className="text-xs text-muted-foreground">{activity.user}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">{activity.timestamp}</p>
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full ${
                        activity.type === "Admin Login"
                          ? "bg-amber-500/20 text-amber-400"
                          : "bg-cyan-500/20 text-cyan-400"
                      }`}
                    >
                      {activity.type}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Activity className="w-12 h-12 mx-auto mb-2 text-muted-foreground/30" />
              <p>No recent activity recorded</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
