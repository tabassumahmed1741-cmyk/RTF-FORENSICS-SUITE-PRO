"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Users, Search, Shield, UserPlus, Key, Lock, Unlock } from "lucide-react"

interface UserAccess {
  id: string
  username: string
  role: string
  station: string
  lastLogin: string
  status: "active" | "inactive" | "locked"
  permissions: string[]
}

export default function UserAccessControl() {
  const [searchQuery, setSearchQuery] = useState("")
  const [users] = useState<UserAccess[]>([
    {
      id: "1",
      username: "Adabor PS",
      role: "Police Station Officer",
      station: "Adabor",
      lastLogin: "2024-01-15 10:30 AM",
      status: "active",
      permissions: ["cdr", "tower", "geo", "reports"],
    },
    {
      id: "2",
      username: "Gulshan PS",
      role: "Police Station Officer",
      station: "Gulshan",
      lastLogin: "2024-01-15 09:15 AM",
      status: "active",
      permissions: ["cdr", "tower", "mutual", "geo", "reports"],
    },
    {
      id: "3",
      username: "Motijheel PS",
      role: "Police Station Officer",
      station: "Motijheel",
      lastLogin: "2024-01-14 04:45 PM",
      status: "inactive",
      permissions: ["cdr", "tower"],
    },
  ])

  const modulePermissions = [
    { id: "cdr", label: "CDR Analyzer" },
    { id: "tower", label: "Tower Dump" },
    { id: "drive", label: "Road Map" },
    { id: "mutual", label: "Mutual Connection" },
    { id: "geo", label: "GEO Intelligence" },
    { id: "reports", label: "Report Generation" },
  ]

  return (
    <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <span className="w-1.5 h-6 bg-gradient-to-b from-amber-500 to-orange-500 rounded-full" />
            User Access Control
          </h1>
          <p className="text-muted-foreground mt-1">Manage user permissions and access levels</p>
        </div>
        <Button className="gap-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500">
          <UserPlus className="w-4 h-4" />
          Add User
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Users</p>
                <p className="text-2xl font-bold text-foreground">654</p>
              </div>
              <Users className="w-8 h-8 text-amber-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active</p>
                <p className="text-2xl font-bold text-emerald-400">127</p>
              </div>
              <Unlock className="w-8 h-8 text-emerald-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Inactive</p>
                <p className="text-2xl font-bold text-muted-foreground">520</p>
              </div>
              <Lock className="w-8 h-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Locked</p>
                <p className="text-2xl font-bold text-red-400">7</p>
              </div>
              <Shield className="w-8 h-8 text-red-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search users by name or station..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9 bg-secondary border-border focus:border-amber-500/50 max-w-md"
        />
      </div>

      {/* User List */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base">User Accounts</CardTitle>
          <CardDescription>Manage individual user permissions and access</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users.map((user) => (
              <div key={user.id} className="p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center">
                      <Users className="w-5 h-5 text-amber-400" />
                    </div>
                    <div>
                      <p className="font-medium">{user.username}</p>
                      <p className="text-xs text-muted-foreground">{user.role}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant="outline"
                      className={
                        user.status === "active"
                          ? "border-emerald-500/50 text-emerald-400"
                          : user.status === "locked"
                            ? "border-red-500/50 text-red-400"
                            : "border-muted-foreground/50"
                      }
                    >
                      {user.status}
                    </Badge>
                    <Button variant="outline" size="sm" className="gap-1 bg-transparent">
                      <Key className="w-3 h-3" />
                      Reset Password
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-6 gap-2">
                  {modulePermissions.map((module) => (
                    <div key={module.id} className="flex items-center justify-between p-2 rounded bg-background/50">
                      <span className="text-xs">{module.label}</span>
                      <Switch checked={user.permissions.includes(module.id)} className="scale-75" />
                    </div>
                  ))}
                </div>

                <p className="text-xs text-muted-foreground mt-3">Last login: {user.lastLogin}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
