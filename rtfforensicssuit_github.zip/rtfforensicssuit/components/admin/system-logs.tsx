"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ClipboardList, Search, Download, Filter, CheckCircle, AlertTriangle, XCircle } from "lucide-react"

interface LogEntry {
  id: string
  timestamp: string
  event: string
  user: string
  type: "login" | "logout" | "action" | "error" | "admin"
  status: "success" | "warning" | "error"
  details?: string
}

export default function SystemLogs() {
  const [searchQuery, setSearchQuery] = useState("")
  const [logs, setLogs] = useState<LogEntry[]>([])
  const [filterType, setFilterType] = useState<string | null>(null)

  useEffect(() => {
    // Compile logs from localStorage
    const loginLogs = JSON.parse(localStorage.getItem("rtf_login_logs") || "[]")
    const adminLogs = JSON.parse(localStorage.getItem("rtf_admin_logs") || "[]")
    const auditLogs = JSON.parse(localStorage.getItem("rtf_audit_logs") || "[]")

    const compiledLogs: LogEntry[] = [
      ...loginLogs.map(
        (
          log: { timestamp: string; thana?: string; username?: string; role?: string; success: boolean },
          index: number,
        ) => ({
          id: `login-${index}`,
          timestamp: log.timestamp,
          event: log.success ? "User Login" : "Failed Login Attempt",
          user: log.thana || log.username || "Unknown",
          type: log.role === "administrator" ? "admin" : "login",
          status: log.success ? "success" : "warning",
          details: `${log.role || "police_station"} login`,
        }),
      ),
      ...adminLogs.map((log: { timestamp: string; username: string; success: boolean }, index: number) => ({
        id: `admin-${index}`,
        timestamp: log.timestamp,
        event: "Admin Login",
        user: log.username,
        type: "admin",
        status: log.success ? "success" : "error",
      })),
      ...auditLogs.map((log: { timestamp: string; username: string; event: string; role: string }, index: number) => ({
        id: `audit-${index}`,
        timestamp: log.timestamp,
        event: log.event === "logout" ? "User Logout" : log.event,
        user: log.username,
        type: "logout",
        status: "success",
      })),
    ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

    setLogs(compiledLogs)
  }, [])

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      searchQuery === "" ||
      log.event.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.user.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesFilter = !filterType || log.type === filterType
    return matchesSearch && matchesFilter
  })

  const exportLogs = () => {
    const csvContent = [
      ["Timestamp", "Event", "User", "Type", "Status"].join(","),
      ...filteredLogs.map((log) => [log.timestamp, log.event, log.user, log.type, log.status].join(",")),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `system_logs_${new Date().toISOString().split("T")[0]}.csv`
    a.click()
  }

  return (
    <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <span className="w-1.5 h-6 bg-gradient-to-b from-amber-500 to-orange-500 rounded-full" />
            System Logs
          </h1>
          <p className="text-muted-foreground mt-1">View audit trail and system activity logs</p>
        </div>
        <Button
          variant="outline"
          className="gap-2 bg-transparent border-border hover:border-amber-500/50"
          onClick={exportLogs}
        >
          <Download className="w-4 h-4" />
          Export Logs
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-4 flex-wrap">
        <div className="relative flex-1 min-w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search logs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-secondary border-border focus:border-amber-500/50"
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant={filterType === null ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterType(null)}
            className={filterType === null ? "bg-amber-600 hover:bg-amber-500" : ""}
          >
            <Filter className="w-4 h-4 mr-1" />
            All
          </Button>
          <Button
            variant={filterType === "login" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterType("login")}
            className={filterType === "login" ? "bg-amber-600 hover:bg-amber-500" : ""}
          >
            Logins
          </Button>
          <Button
            variant={filterType === "admin" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterType("admin")}
            className={filterType === "admin" ? "bg-amber-600 hover:bg-amber-500" : ""}
          >
            Admin
          </Button>
          <Button
            variant={filterType === "logout" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterType("logout")}
            className={filterType === "logout" ? "bg-amber-600 hover:bg-amber-500" : ""}
          >
            Logouts
          </Button>
        </div>
      </div>

      {/* Logs Table */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ClipboardList className="w-4 h-4 text-amber-400" />
            Activity Log
          </CardTitle>
          <CardDescription>Showing {filteredLogs.length} log entries</CardDescription>
        </CardHeader>
        <CardContent>
          {filteredLogs.length > 0 ? (
            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {filteredLogs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {log.status === "success" ? (
                      <CheckCircle className="w-4 h-4 text-emerald-400" />
                    ) : log.status === "warning" ? (
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-400" />
                    )}
                    <div>
                      <p className="text-sm font-medium">{log.event}</p>
                      <p className="text-xs text-muted-foreground">{log.user}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge
                      variant="outline"
                      className={
                        log.type === "admin"
                          ? "border-amber-500/50 text-amber-400"
                          : log.type === "login"
                            ? "border-cyan-500/50 text-cyan-400"
                            : "border-muted-foreground/50"
                      }
                    >
                      {log.type}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{new Date(log.timestamp).toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <ClipboardList className="w-12 h-12 mx-auto mb-2 text-muted-foreground/30" />
              <p>No log entries found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
