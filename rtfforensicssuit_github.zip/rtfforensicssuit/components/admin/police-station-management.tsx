"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Building2, Search, MapPin, Users, Plus, Edit, Trash2 } from "lucide-react"
import { bangladeshThanas, getAllThanas } from "@/lib/bangladesh-thanas"

export default function PoliceStationManagement() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedDivision, setSelectedDivision] = useState<string | null>(null)

  const allThanas = useMemo(() => getAllThanas(), [])
  const divisions = Object.keys(bangladeshThanas)

  const filteredThanas = useMemo(() => {
    return allThanas.filter((thana) => {
      const matchesSearch =
        searchQuery === "" ||
        thana.thana.toLowerCase().includes(searchQuery.toLowerCase()) ||
        thana.district.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesDivision = !selectedDivision || thana.division === selectedDivision
      return matchesSearch && matchesDivision
    })
  }, [allThanas, searchQuery, selectedDivision])

  const stats = useMemo(() => {
    const divisionCounts: Record<string, number> = {}
    allThanas.forEach((thana) => {
      divisionCounts[thana.division] = (divisionCounts[thana.division] || 0) + 1
    })
    return {
      total: allThanas.length,
      divisions: Object.keys(bangladeshThanas).length,
      divisionCounts,
    }
  }, [allThanas])

  return (
    <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <span className="w-1.5 h-6 bg-gradient-to-b from-amber-500 to-orange-500 rounded-full" />
            Police Station Management
          </h1>
          <p className="text-muted-foreground mt-1">Manage all registered police stations across Bangladesh</p>
        </div>
        <Button className="gap-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500">
          <Plus className="w-4 h-4" />
          Add Station
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Stations</p>
                <p className="text-2xl font-bold text-foreground">{stats.total}</p>
              </div>
              <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center">
                <Building2 className="w-5 h-5 text-amber-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Divisions</p>
                <p className="text-2xl font-bold text-foreground">{stats.divisions}</p>
              </div>
              <div className="w-10 h-10 bg-cyan-500/10 rounded-lg flex items-center justify-center">
                <MapPin className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Users</p>
                <p className="text-2xl font-bold text-foreground">127</p>
              </div>
              <div className="w-10 h-10 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Filtered</p>
                <p className="text-2xl font-bold text-foreground">{filteredThanas.length}</p>
              </div>
              <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center">
                <Search className="w-5 h-5 text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex gap-4 flex-wrap">
        <div className="relative flex-1 min-w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by station or district name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-secondary border-border focus:border-amber-500/50"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant={selectedDivision === null ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedDivision(null)}
            className={selectedDivision === null ? "bg-amber-600 hover:bg-amber-500" : ""}
          >
            All
          </Button>
          {divisions.map((division) => (
            <Button
              key={division}
              variant={selectedDivision === division ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedDivision(division)}
              className={selectedDivision === division ? "bg-amber-600 hover:bg-amber-500" : ""}
            >
              {division.replace(" Division", "")}
            </Button>
          ))}
        </div>
      </div>

      {/* Station List */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base">Police Stations</CardTitle>
          <CardDescription>Showing {filteredThanas.length} stations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {filteredThanas.slice(0, 50).map((thana, index) => (
              <div
                key={`${thana.value}-${index}`}
                className="flex items-center justify-between p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center">
                    <Building2 className="w-4 h-4 text-amber-400" />
                  </div>
                  <div>
                    <p className="font-medium">{thana.thana} Police Station</p>
                    <p className="text-xs text-muted-foreground">
                      {thana.district}, {thana.division}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">
                    Active
                  </Badge>
                  <Button variant="ghost" size="icon" className="w-8 h-8">
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="w-8 h-8 text-destructive hover:text-destructive">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
            {filteredThanas.length > 50 && (
              <p className="text-center text-sm text-muted-foreground py-4">
                Showing 50 of {filteredThanas.length} results. Use search to narrow down.
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
