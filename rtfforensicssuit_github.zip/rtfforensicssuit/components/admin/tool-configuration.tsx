"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Settings, Save, PhoneCall, Radio, Route, Users, Map, FileText } from "lucide-react"

export default function ToolConfiguration() {
  const tools = [
    { id: "cdr", name: "CDR Analyzer", icon: PhoneCall, enabled: true },
    { id: "tower", name: "Tower Dump Analyzer", icon: Radio, enabled: true },
    { id: "drive", name: "Road Map Analyzer", icon: Route, enabled: true },
    { id: "mutual", name: "Mutual Connection", icon: Users, enabled: true },
    { id: "geo", name: "GEO Intelligence", icon: Map, enabled: true },
    { id: "reports", name: "Report Generator", icon: FileText, enabled: true },
  ]

  return (
    <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <span className="w-1.5 h-6 bg-gradient-to-b from-amber-500 to-orange-500 rounded-full" />
            Tool Configuration
          </h1>
          <p className="text-muted-foreground mt-1">Configure analysis tools and module settings</p>
        </div>
        <Button className="gap-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500">
          <Save className="w-4 h-4" />
          Save Changes
        </Button>
      </div>

      {/* Module Toggles */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Settings className="w-4 h-4 text-amber-400" />
            Module Status
          </CardTitle>
          <CardDescription>Enable or disable analysis modules</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tools.map((tool) => {
              const Icon = tool.icon
              return (
                <div
                  key={tool.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 border border-border"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                      <Icon className="w-5 h-5 text-amber-400" />
                    </div>
                    <div>
                      <p className="font-medium">{tool.name}</p>
                      <p className="text-xs text-muted-foreground">{tool.enabled ? "Active" : "Disabled"}</p>
                    </div>
                  </div>
                  <Switch defaultChecked={tool.enabled} />
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* File Settings */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base">File Processing Settings</CardTitle>
          <CardDescription>Configure file upload and processing limits</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Max File Size (MB)</Label>
              <Input type="number" defaultValue={100} className="bg-secondary border-border" />
            </div>
            <div className="space-y-2">
              <Label>Max Records per File</Label>
              <Input type="number" defaultValue={1000000} className="bg-secondary border-border" />
            </div>
            <div className="space-y-2">
              <Label>Allowed File Types</Label>
              <Input defaultValue=".xlsx, .xls, .csv" className="bg-secondary border-border" />
            </div>
            <div className="space-y-2">
              <Label>Session Timeout (minutes)</Label>
              <Input type="number" defaultValue={60} className="bg-secondary border-border" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* API Settings */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base">External API Configuration</CardTitle>
          <CardDescription>Configure external service integrations</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>UNWIREDLAB API Key (GEO Intelligence)</Label>
            <Input
              type="password"
              defaultValue="pk.0b2d67c56a132924f9191cb9336bfb11"
              className="bg-secondary border-border font-mono"
            />
            <p className="text-xs text-muted-foreground">Used for cell tower geolocation</p>
          </div>
          <div className="space-y-2">
            <Label>Bangladesh MCC Code</Label>
            <Input defaultValue="470" className="bg-secondary border-border" disabled />
            <p className="text-xs text-muted-foreground">Fixed for Bangladesh mobile networks</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
