"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { HardDrive, Download, Upload, Clock, CheckCircle, AlertTriangle, Trash2, RefreshCw } from "lucide-react"

interface BackupEntry {
  id: string
  date: string
  size: string
  type: "full" | "incremental"
  status: "completed" | "failed"
}

export default function BackupRestore() {
  const [isBackingUp, setIsBackingUp] = useState(false)
  const [backupProgress, setBackupProgress] = useState(0)

  const [backups] = useState<BackupEntry[]>([
    { id: "1", date: "2024-01-15 10:00 AM", size: "2.3 GB", type: "full", status: "completed" },
    { id: "2", date: "2024-01-14 10:00 AM", size: "1.8 GB", type: "incremental", status: "completed" },
    { id: "3", date: "2024-01-13 10:00 AM", size: "2.1 GB", type: "full", status: "completed" },
    { id: "4", date: "2024-01-12 10:00 AM", size: "1.5 GB", type: "incremental", status: "failed" },
  ])

  const startBackup = () => {
    setIsBackingUp(true)
    setBackupProgress(0)

    const interval = setInterval(() => {
      setBackupProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsBackingUp(false)
          return 100
        }
        return prev + 10
      })
    }, 500)
  }

  return (
    <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <span className="w-1.5 h-6 bg-gradient-to-b from-amber-500 to-orange-500 rounded-full" />
            Backup & Restore
          </h1>
          <p className="text-muted-foreground mt-1">Manage system backups and data restoration</p>
        </div>
      </div>

      {/* Backup Actions */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="bg-card border-amber-500/20">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Download className="w-4 h-4 text-amber-400" />
              Create Backup
            </CardTitle>
            <CardDescription>Create a new system backup</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {isBackingUp ? (
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span>Backup in progress...</span>
                  <span>{backupProgress}%</span>
                </div>
                <Progress value={backupProgress} className="h-2" />
              </div>
            ) : (
              <div className="space-y-3">
                <Button
                  className="w-full gap-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500"
                  onClick={startBackup}
                >
                  <HardDrive className="w-4 h-4" />
                  Start Full Backup
                </Button>
                <Button variant="outline" className="w-full gap-2 bg-transparent">
                  <RefreshCw className="w-4 h-4" />
                  Incremental Backup
                </Button>
              </div>
            )}
            <p className="text-xs text-muted-foreground">Last backup: 2 hours ago</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Upload className="w-4 h-4 text-cyan-400" />
              Restore Data
            </CardTitle>
            <CardDescription>Restore from a previous backup</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button variant="outline" className="w-full gap-2 bg-transparent">
              <Upload className="w-4 h-4" />
              Select Backup to Restore
            </Button>
            <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400 mt-0.5" />
                <div className="text-xs">
                  <p className="font-medium text-amber-400">Warning</p>
                  <p className="text-muted-foreground">Restoring will overwrite current data</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Backup History */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            Backup History
          </CardTitle>
          <CardDescription>Previous backup records</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {backups.map((backup) => (
              <div
                key={backup.id}
                className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  {backup.status === "completed" ? (
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                  )}
                  <div>
                    <p className="font-medium">{backup.date}</p>
                    <p className="text-xs text-muted-foreground">{backup.size}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge
                    variant="outline"
                    className={
                      backup.type === "full" ? "border-cyan-500/50 text-cyan-400" : "border-muted-foreground/50"
                    }
                  >
                    {backup.type}
                  </Badge>
                  <Badge
                    variant="outline"
                    className={
                      backup.status === "completed"
                        ? "border-emerald-500/50 text-emerald-400"
                        : "border-red-500/50 text-red-400"
                    }
                  >
                    {backup.status}
                  </Badge>
                  <Button variant="ghost" size="icon" className="w-8 h-8">
                    <Download className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="w-8 h-8 text-destructive hover:text-destructive">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
