"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Database, Plus, Edit, Trash2, ArrowRight } from "lucide-react"

export default function DataMappingRules() {
  const mappingRules = [
    {
      id: "1",
      name: "Grameenphone CDR",
      source: "GP Format",
      fields: ["MSISDN", "B_NUMBER", "IMEI", "LAC", "CI", "DURATION"],
      status: "active",
    },
    {
      id: "2",
      name: "Robi CDR",
      source: "Robi Format",
      fields: ["A_PARTY", "B_PARTY", "DEVICE_ID", "LOCATION", "TIME"],
      status: "active",
    },
    {
      id: "3",
      name: "Banglalink CDR",
      source: "BL Format",
      fields: ["CALLER", "CALLED", "IMEI", "CELL_ID", "TIMESTAMP"],
      status: "active",
    },
    {
      id: "4",
      name: "Tower Dump Standard",
      source: "Universal",
      fields: ["MSISDN", "IMEI", "IMSI", "LAC", "CI", "DATETIME"],
      status: "active",
    },
  ]

  return (
    <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <span className="w-1.5 h-6 bg-gradient-to-b from-amber-500 to-orange-500 rounded-full" />
            Data Mapping Rules
          </h1>
          <p className="text-muted-foreground mt-1">Configure column mapping rules for different data sources</p>
        </div>
        <Button className="gap-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500">
          <Plus className="w-4 h-4" />
          Add Mapping Rule
        </Button>
      </div>

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Database className="w-4 h-4 text-amber-400" />
            Configured Mappings
          </CardTitle>
          <CardDescription>Define how different file formats map to standard fields</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mappingRules.map((rule) => (
              <div
                key={rule.id}
                className="p-4 rounded-lg bg-secondary/30 border border-border hover:border-amber-500/30 transition-colors"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{rule.name}</p>
                      <Badge variant="outline" className="text-xs border-emerald-500/50 text-emerald-400">
                        {rule.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Source: {rule.source}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="icon" className="w-8 h-8">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="w-8 h-8 text-destructive hover:text-destructive">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs text-muted-foreground">Fields:</span>
                  {rule.fields.map((field, index) => (
                    <span key={field} className="flex items-center gap-1">
                      <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 text-xs font-mono">
                        {field}
                      </span>
                      {index < rule.fields.length - 1 && <ArrowRight className="w-3 h-3 text-muted-foreground" />}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
