"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Lock, Key, AlertTriangle, Save } from "lucide-react"

export default function SecuritySettings() {
  return (
    <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <span className="w-1.5 h-6 bg-gradient-to-b from-amber-500 to-orange-500 rounded-full" />
            Security Settings
          </h1>
          <p className="text-muted-foreground mt-1">Configure system security and authentication</p>
        </div>
        <Button className="gap-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500">
          <Save className="w-4 h-4" />
          Save Settings
        </Button>
      </div>

      {/* Password Policy */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Key className="w-4 h-4 text-amber-400" />
            Password Policy
          </CardTitle>
          <CardDescription>Configure password requirements</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Minimum Password Length</Label>
              <Input type="number" defaultValue={8} className="bg-secondary border-border" />
            </div>
            <div className="space-y-2">
              <Label>Password Expiry (days)</Label>
              <Input type="number" defaultValue={90} className="bg-secondary border-border" />
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Require Special Characters</p>
              <p className="text-xs text-muted-foreground">Passwords must include @#$%</p>
            </div>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Require Uppercase Letters</p>
              <p className="text-xs text-muted-foreground">At least one uppercase letter required</p>
            </div>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Force Password Change on First Login</p>
              <p className="text-xs text-muted-foreground">New users must change password</p>
            </div>
            <Switch />
          </div>
        </CardContent>
      </Card>

      {/* Session Security */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Lock className="w-4 h-4 text-amber-400" />
            Session Security
          </CardTitle>
          <CardDescription>Configure session and login settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Session Timeout (minutes)</Label>
              <Input type="number" defaultValue={30} className="bg-secondary border-border" />
            </div>
            <div className="space-y-2">
              <Label>Max Failed Login Attempts</Label>
              <Input type="number" defaultValue={5} className="bg-secondary border-border" />
            </div>
            <div className="space-y-2">
              <Label>Account Lockout Duration (minutes)</Label>
              <Input type="number" defaultValue={30} className="bg-secondary border-border" />
            </div>
            <div className="space-y-2">
              <Label>IP Whitelist (comma separated)</Label>
              <Input placeholder="Leave empty to allow all" className="bg-secondary border-border" />
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Enable IP Logging</p>
              <p className="text-xs text-muted-foreground">Log IP address for each login</p>
            </div>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Enable CAPTCHA</p>
              <p className="text-xs text-muted-foreground">Show CAPTCHA after failed attempts</p>
            </div>
            <Switch />
          </div>
        </CardContent>
      </Card>

      {/* Security Alerts */}
      <Card className="bg-card border-amber-500/20">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            Security Alerts
          </CardTitle>
          <CardDescription>Configure security notifications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Email on Failed Login Attempts</p>
              <p className="text-xs text-muted-foreground">Send alert after 3 failed attempts</p>
            </div>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Email on Admin Login</p>
              <p className="text-xs text-muted-foreground">Notify when admin account logs in</p>
            </div>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Email on Data Export</p>
              <p className="text-xs text-muted-foreground">Notify when large data exports occur</p>
            </div>
            <Switch />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
