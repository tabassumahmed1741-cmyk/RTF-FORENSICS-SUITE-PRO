# RTF Forensics Suite

This is a Next.js application for a forensics suite, featuring modules for CDR analysis, Geo-Intelligence, Tower Dump analysis, and more.

## Getting Started

1.  **Install dependencies:**
    ```bash
    pnpm install
    ```
2.  **Run the development server:**
    ```bash
    pnpm run dev
    ```
3.  Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Project Structure

The application is built with Next.js, React, and Tailwind CSS.

*   `app/`: Contains the main application routes and layout.
*   `components/`: Reusable UI components.
*   `lib/`: Utility functions and data logic.
*   `styles/`: Global CSS styles.
