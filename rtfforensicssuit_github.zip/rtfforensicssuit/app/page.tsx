"use client"

import { AuthProvider, useAuth } from "@/lib/auth-context"
import { DataStoreProvider } from "@/lib/data-store"
import LoginPage from "@/components/login-page"
import Dashboard from "@/components/dashboard"

function AppContent() {
  const { isAuthenticated, isLoading } = useAuth()

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">Loading RTF Forensics Suite...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return <LoginPage />
  }

  return <Dashboard />
}

export default function Home() {
  return (
    <AuthProvider>
      <DataStoreProvider>
        <AppContent />
      </DataStoreProvider>
    </AuthProvider>
  )
}
