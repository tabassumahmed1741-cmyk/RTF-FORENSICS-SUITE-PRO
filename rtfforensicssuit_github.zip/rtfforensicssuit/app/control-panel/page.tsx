"use client"

import { useState, useEffect } from "react"
import ControlPanelLogin from "@/components/control-panel/control-panel-login"
import ControlPanelDashboard from "@/components/control-panel/control-panel-dashboard"

export default function ControlPanelPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [adminUser, setAdminUser] = useState<{ username: string; role: string; accessLevel: number } | null>(null)

  useEffect(() => {
    const adminSession = localStorage.getItem("rtf_control_panel_session")
    if (adminSession) {
      try {
        const session = JSON.parse(adminSession)
        const loginTime = new Date(session.loginTime)
        const now = new Date()
        const hoursDiff = (now.getTime() - loginTime.getTime()) / (1000 * 60 * 60)

        if (hoursDiff < 8) {
          setIsAuthenticated(true)
          setAdminUser({
            username: session.username,
            role: session.role,
            accessLevel: session.accessLevel,
          })
        } else {
          localStorage.removeItem("rtf_control_panel_session")
        }
      } catch {
        localStorage.removeItem("rtf_control_panel_session")
      }
    }
    setIsLoading(false)
  }, [])

  const handleLogin = (username: string, password: string): boolean => {
    if (username === "rifat_admin" && password === "admin123") {
      const session = {
        username,
        role: "System Administrator",
        loginTime: new Date().toISOString(),
        accessLevel: 3,
      }
      localStorage.setItem("rtf_control_panel_session", JSON.stringify(session))
      setIsAuthenticated(true)
      setAdminUser({
        username: session.username,
        role: session.role,
        accessLevel: session.accessLevel,
      })

      const logs = JSON.parse(localStorage.getItem("rtf_admin_audit_logs") || "[]")
      logs.push({
        id: Date.now(),
        action: "Admin Login",
        user: username,
        timestamp: new Date().toISOString(),
        status: "success",
        ip: "192.168.1.1",
      })
      localStorage.setItem("rtf_admin_audit_logs", JSON.stringify(logs.slice(-500)))

      return true
    }
    return false
  }

  const handleLogout = () => {
    if (adminUser) {
      const logs = JSON.parse(localStorage.getItem("rtf_admin_audit_logs") || "[]")
      logs.push({
        id: Date.now(),
        action: "Admin Logout",
        user: adminUser.username,
        timestamp: new Date().toISOString(),
        status: "success",
        ip: "192.168.1.1",
      })
      localStorage.setItem("rtf_admin_audit_logs", JSON.stringify(logs.slice(-500)))
    }

    localStorage.removeItem("rtf_control_panel_session")
    setIsAuthenticated(false)
    setAdminUser(null)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">Loading Control Panel...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return <ControlPanelLogin onLogin={handleLogin} />
  }

  return <ControlPanelDashboard adminUser={adminUser!} onLogout={handleLogout} />
}
