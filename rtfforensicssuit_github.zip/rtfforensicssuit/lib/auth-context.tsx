"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface ThanaDetails {
  division: string
  district: string
  thana: string
}

export type UserRole = "police_station" | "administrator"

interface User {
  username: string
  role: UserRole
  displayRole: string
  loginTime: Date
  thanaDetails?: ThanaDetails
  isAdmin?: boolean
}

interface AuthContextType {
  user: User | null
  login: (username: string, password: string, thanaDetails?: ThanaDetails) => boolean
  adminLogin: (username: string, password: string) => boolean
  logout: () => void
  isAuthenticated: boolean
  isLoading: boolean
  isAdmin: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const MASTER_PASSWORD = "admin123"
const ADMIN_USERNAME = "rifat_admin"
const ADMIN_PASSWORD = "admin123"

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const stored = localStorage.getItem("rtf_user")
    if (stored) {
      try {
        const userData = JSON.parse(stored)
        userData.loginTime = new Date(userData.loginTime)
        setUser(userData)
      } catch {
        localStorage.removeItem("rtf_user")
      }
    }
    setIsLoading(false)
  }, [])

  const login = (username: string, password: string, thanaDetails?: ThanaDetails) => {
    // Reject if trying to login with admin username through regular login
    if (username.toLowerCase() === ADMIN_USERNAME.toLowerCase()) {
      return false
    }

    if (password === MASTER_PASSWORD && username) {
      const userData: User = {
        username: username,
        role: "police_station",
        displayRole: "Police Station Officer",
        loginTime: new Date(),
        thanaDetails: thanaDetails,
        isAdmin: false,
      }
      setUser(userData)
      localStorage.setItem("rtf_user", JSON.stringify(userData))

      const loginLog = {
        timestamp: new Date().toISOString(),
        thana: username,
        division: thanaDetails?.division || "",
        district: thanaDetails?.district || "",
        role: "police_station",
        success: true,
      }
      const existingLogs = JSON.parse(localStorage.getItem("rtf_login_logs") || "[]")
      existingLogs.push(loginLog)
      localStorage.setItem("rtf_login_logs", JSON.stringify(existingLogs.slice(-100)))

      return true
    }
    return false
  }

  const adminLogin = (username: string, password: string) => {
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      const userData: User = {
        username: username,
        role: "administrator",
        displayRole: "System Administrator",
        loginTime: new Date(),
        isAdmin: true,
      }
      setUser(userData)
      localStorage.setItem("rtf_user", JSON.stringify(userData))

      const loginLog = {
        timestamp: new Date().toISOString(),
        username: username,
        role: "administrator",
        success: true,
      }
      const existingLogs = JSON.parse(localStorage.getItem("rtf_admin_logs") || "[]")
      existingLogs.push(loginLog)
      localStorage.setItem("rtf_admin_logs", JSON.stringify(existingLogs.slice(-100)))

      return true
    }
    return false
  }

  const logout = () => {
    // Log logout event
    if (user) {
      const logoutLog = {
        timestamp: new Date().toISOString(),
        username: user.username,
        role: user.role,
        event: "logout",
      }
      const existingLogs = JSON.parse(localStorage.getItem("rtf_audit_logs") || "[]")
      existingLogs.push(logoutLog)
      localStorage.setItem("rtf_audit_logs", JSON.stringify(existingLogs.slice(-500)))
    }

    setUser(null)
    localStorage.removeItem("rtf_user")
    localStorage.removeItem("rtf_sessions")
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        adminLogin,
        logout,
        isAuthenticated: !!user,
        isLoading,
        isAdmin: user?.role === "administrator",
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
