import * as XLSX from "xlsx"

export interface ParsedData {
  headers: string[]
  rows: Record<string, string>[]
  analytics?: {
    uniqueBParty?: number
    totalDuration?: string
    towerHits?: number
    uniqueMSISDN?: number
    uniqueIMEI?: number
    timeSpan?: string
    towerCount?: number
    firstActivity?: string
    lastActivity?: string
    incomingCalls?: number
    outgoingCalls?: number
    smsCount?: number
    dataUsage?: string
    topBParty?: Array<{ number: string; count: number }>
    providers?: Record<string, number>
  }
  rawText?: string
}

export async function parseFile(file: File): Promise<ParsedData> {
  const extension = file.name.split(".").pop()?.toLowerCase()

  if (extension === "xlsx" || extension === "xls") {
    return parseExcelFile(file)
  } else {
    return parseTextFile(file)
  }
}

async function parseExcelFile(file: File): Promise<ParsedData> {
  const arrayBuffer = await file.arrayBuffer()
  const workbook = XLSX.read(arrayBuffer, { type: "array" })
  const sheetName = workbook.SheetNames[0]
  const worksheet = workbook.Sheets[sheetName]
  const jsonData = XLSX.utils.sheet_to_json<Record<string, string>>(worksheet, { defval: "" })

  if (jsonData.length === 0) {
    return { headers: [], rows: [] }
  }

  const headers = Object.keys(jsonData[0])
  const rows = jsonData
    .map((row) => {
      const cleanRow: Record<string, string> = {}
      headers.forEach((header) => {
        cleanRow[header] = String(row[header] ?? "").trim()
      })
      return cleanRow
    })
    .filter((row) => Object.values(row).some((v) => v !== ""))

  const analytics = generateAnalytics(headers, rows)
  return { headers, rows, analytics }
}

async function parseTextFile(file: File): Promise<ParsedData> {
  const text = await file.text()
  const lines = text.trim().split("\n")

  if (lines.length === 0) {
    return { headers: [], rows: [], rawText: text }
  }

  const firstLine = lines[0]
  let delimiter = ","
  if (firstLine.includes("\t")) delimiter = "\t"
  else if (firstLine.includes(";")) delimiter = ";"
  else if (firstLine.includes("|")) delimiter = "|"

  const headers = firstLine.split(delimiter).map((h) => h.trim().replace(/^["']|["']$/g, ""))

  const rows = lines
    .slice(1)
    .map((line) => {
      const values = line.split(delimiter).map((v) => v.trim().replace(/^["']|["']$/g, ""))
      const row: Record<string, string> = {}
      headers.forEach((header, index) => {
        row[header] = values[index] || ""
      })
      return row
    })
    .filter((row) => Object.values(row).some((v) => v !== ""))

  const analytics = generateAnalytics(headers, rows)
  return { headers, rows, analytics, rawText: text }
}

function generateAnalytics(headers: string[], rows: Record<string, string>[]) {
  const analytics: ParsedData["analytics"] = {}
  const lowerHeaders = headers.map((h) => h.toLowerCase())

  // Find MSISDN/Phone columns
  const msisdnColumn = headers.find(
    (h, i) =>
      lowerHeaders[i].includes("msisdn") ||
      lowerHeaders[i].includes("phone") ||
      lowerHeaders[i].includes("number") ||
      lowerHeaders[i].includes("b_party") ||
      lowerHeaders[i].includes("b-party") ||
      lowerHeaders[i].includes("called") ||
      lowerHeaders[i].includes("calling"),
  )

  const aPartyColumn = headers.find(
    (h, i) =>
      lowerHeaders[i].includes("a_party") || lowerHeaders[i].includes("a-party") || lowerHeaders[i].includes("calling"),
  )

  if (msisdnColumn) {
    const uniqueNumbers = new Set(rows.map((r) => r[msisdnColumn]).filter(Boolean))
    analytics.uniqueBParty = uniqueNumbers.size
    analytics.uniqueMSISDN = uniqueNumbers.size

    // Calculate top B-party numbers
    const bPartyCount: Record<string, number> = {}
    rows.forEach((r) => {
      const num = r[msisdnColumn]
      if (num) {
        bPartyCount[num] = (bPartyCount[num] || 0) + 1
      }
    })
    analytics.topBParty = Object.entries(bPartyCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 100)
      .map(([number, count]) => ({ number, count }))
  }

  // Find IMEI column
  const imeiColumn = headers.find((h, i) => lowerHeaders[i].includes("imei"))
  if (imeiColumn) {
    const uniqueIMEI = new Set(rows.map((r) => r[imeiColumn]).filter(Boolean))
    analytics.uniqueIMEI = uniqueIMEI.size
  }

  // Find LAC/CI columns for tower analysis
  const lacColumn = headers.find((h, i) => lowerHeaders[i].includes("lac"))
  const ciColumn = headers.find((h, i) => lowerHeaders[i].includes("ci") || lowerHeaders[i].includes("cell"))

  if (lacColumn || ciColumn) {
    const towerSet = new Set(rows.map((r) => `${r[lacColumn || ""] || ""}-${r[ciColumn || ""] || ""}`))
    analytics.towerHits = rows.length
    analytics.towerCount = towerSet.size
  }

  // Find time/date column
  const timeColumn = headers.find(
    (h, i) =>
      lowerHeaders[i].includes("time") || lowerHeaders[i].includes("date") || lowerHeaders[i].includes("timestamp"),
  )

  if (timeColumn && rows.length > 0) {
    const sortedRows = [...rows].sort((a, b) => {
      const dateA = new Date(a[timeColumn] || 0)
      const dateB = new Date(b[timeColumn] || 0)
      return dateA.getTime() - dateB.getTime()
    })
    analytics.firstActivity = formatDateTime(sortedRows[0][timeColumn])
    analytics.lastActivity = formatDateTime(sortedRows[sortedRows.length - 1][timeColumn])
    analytics.timeSpan = `${analytics.firstActivity} - ${analytics.lastActivity}`
  }

  // Find call type column for incoming/outgoing analysis
  const typeColumn = headers.find(
    (h, i) =>
      lowerHeaders[i].includes("type") ||
      lowerHeaders[i].includes("direction") ||
      lowerHeaders[i].includes("call_type"),
  )

  if (typeColumn) {
    let incoming = 0
    let outgoing = 0
    let sms = 0

    rows.forEach((r) => {
      const type = r[typeColumn]?.toLowerCase() || ""
      if (type.includes("in") || type.includes("mt") || type.includes("received")) {
        incoming++
      } else if (type.includes("out") || type.includes("mo") || type.includes("dialed")) {
        outgoing++
      }
      if (type.includes("sms") || type.includes("message")) {
        sms++
      }
    })

    analytics.incomingCalls = incoming
    analytics.outgoingCalls = outgoing
    analytics.smsCount = sms
  }

  // Find duration column
  const durationColumn = headers.find(
    (h, i) =>
      lowerHeaders[i].includes("duration") || lowerHeaders[i].includes("length") || lowerHeaders[i].includes("seconds"),
  )

  if (durationColumn) {
    const totalSeconds = rows.reduce((sum, row) => {
      const val = Number.parseInt(row[durationColumn]) || 0
      return sum + val
    }, 0)
    const hours = Math.floor(totalSeconds / 3600)
    const minutes = Math.floor((totalSeconds % 3600) / 60)
    const seconds = totalSeconds % 60
    analytics.totalDuration = `${hours}h ${minutes}m ${seconds}s`
  } else {
    analytics.totalDuration = "N/A"
  }

  // Find provider/operator column
  const providerColumn = headers.find(
    (h, i) =>
      lowerHeaders[i].includes("provider") ||
      lowerHeaders[i].includes("operator") ||
      lowerHeaders[i].includes("network"),
  )

  if (providerColumn) {
    const providers: Record<string, number> = {}
    rows.forEach((r) => {
      const provider = r[providerColumn]
      if (provider) {
        providers[provider] = (providers[provider] || 0) + 1
      }
    })
    analytics.providers = providers
  }

  return analytics
}

export function formatDateTime(dateStr: string): string {
  if (!dateStr) return ""
  try {
    const date = new Date(dateStr)
    if (isNaN(date.getTime())) return dateStr

    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, "0")
    const day = String(date.getDate()).padStart(2, "0")
    let hours = date.getHours()
    const minutes = String(date.getMinutes()).padStart(2, "0")
    const seconds = String(date.getSeconds()).padStart(2, "0")
    const ampm = hours >= 12 ? "PM" : "AM"
    hours = hours % 12 || 12

    return `${year}-${month}-${day} ${String(hours).padStart(2, "0")}:${minutes}:${seconds} ${ampm}`
  } catch {
    return dateStr
  }
}

export function normalizeIMEI(imei: string): string {
  const cleaned = imei.replace(/\D/g, "")
  if (cleaned.length === 14 || cleaned.length === 15) {
    return cleaned
  }
  return imei
}

export function normalizeMSISDN(msisdn: string): string {
  const cleaned = msisdn.replace(/\D/g, "")
  // Handle Bangladesh numbers
  if (cleaned.startsWith("880")) {
    return cleaned
  } else if (cleaned.startsWith("0")) {
    return "880" + cleaned.substring(1)
  }
  return cleaned
}
