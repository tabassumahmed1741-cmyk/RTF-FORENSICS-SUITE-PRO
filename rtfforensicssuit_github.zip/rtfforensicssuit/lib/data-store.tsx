"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"
import type { ParsedData } from "@/lib/file-parser"

interface AnalysisSession {
  id: string
  module: string
  fileName: string
  uploadedAt: Date
  data: ParsedData
}

interface DataStoreContextType {
  sessions: AnalysisSession[]
  activeSession: AnalysisSession | null
  addSession: (module: string, fileName: string, data: ParsedData) => string
  setActiveSession: (id: string | null) => void
  getSessionsByModule: (module: string) => AnalysisSession[]
  removeSession: (id: string) => void
  clearAllSessions: () => void
  stats: {
    totalSessions: number
    totalRecordsProcessed: number
    modulesUsed: string[]
  }
}

const DataStoreContext = createContext<DataStoreContextType | undefined>(undefined)

export function DataStoreProvider({ children }: { children: ReactNode }) {
  const [sessions, setSessions] = useState<AnalysisSession[]>([])
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null)

  const addSession = useCallback((module: string, fileName: string, data: ParsedData) => {
    const id = `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    const newSession: AnalysisSession = {
      id,
      module,
      fileName,
      uploadedAt: new Date(),
      data,
    }
    setSessions((prev) => [...prev, newSession])
    setActiveSessionId(id)
    return id
  }, [])

  const setActiveSession = useCallback((id: string | null) => {
    setActiveSessionId(id)
  }, [])

  const getSessionsByModule = useCallback(
    (module: string) => {
      return sessions.filter((s) => s.module === module)
    },
    [sessions],
  )

  const removeSession = useCallback(
    (id: string) => {
      setSessions((prev) => prev.filter((s) => s.id !== id))
      if (activeSessionId === id) {
        setActiveSessionId(null)
      }
    },
    [activeSessionId],
  )

  const clearAllSessions = useCallback(() => {
    setSessions([])
    setActiveSessionId(null)
  }, [])

  const activeSession = sessions.find((s) => s.id === activeSessionId) || null

  const stats = {
    totalSessions: sessions.length,
    totalRecordsProcessed: sessions.reduce((sum, s) => sum + s.data.rows.length, 0),
    modulesUsed: [...new Set(sessions.map((s) => s.module))],
  }

  return (
    <DataStoreContext.Provider
      value={{
        sessions,
        activeSession,
        addSession,
        setActiveSession,
        getSessionsByModule,
        removeSession,
        clearAllSessions,
        stats,
      }}
    >
      {children}
    </DataStoreContext.Provider>
  )
}

export function useDataStore() {
  const context = useContext(DataStoreContext)
  if (context === undefined) {
    throw new Error("useDataStore must be used within a DataStoreProvider")
  }
  return context
}
