// RTF Forensics Suite - Intelligent Column Mapping Engine
// Comprehensive auto-mapping with synonym matching, pattern recognition, and confidence scoring

export interface ColumnMapping {
  sourceColumn: string
  targetColumn: string
  confidence: number
  matchType: "exact" | "synonym" | "pattern" | "fuzzy" | "manual" | "none"
  sampleData?: string[]
  dataType?: "text" | "number" | "date" | "time" | "phone" | "imei" | "imsi"
}

export interface MappingTemplate {
  id: string
  name: string
  description: string
  sourceSystem: string
  mappings: ColumnMapping[]
  createdAt: string
  updatedAt: string
  usageCount: number
}

export interface ValidationResult {
  isValid: boolean
  errors: ValidationError[]
  warnings: ValidationWarning[]
}

export interface ValidationError {
  column: string
  row?: number
  message: string
  severity: "error" | "warning"
}

export interface ValidationWarning {
  column: string
  message: string
  affectedRows: number
}

// Target columns for CDR data
export const TARGET_COLUMNS = {
  cdr: [
    {
      name: "Operator",
      required: false,
      description: "Telecom operator/provider name",
      aliases: ["Provider", "ProviderName", "Carrier", "TelecomCompany", "Network", "ServiceProvider"],
    },
    {
      name: "Party A",
      required: true,
      description: "Calling/source number",
      aliases: [
        "Aparty",
        "A_Party",
        "A-Party",
        "Caller",
        "Source",
        "Originator",
        "CallingNumber",
        "FromNumber",
        "MSISDN_A",
      ],
    },
    {
      name: "Party B",
      required: true,
      description: "Called/destination number",
      aliases: [
        "Bparty",
        "B_Party",
        "B-Party",
        "Called",
        "Destination",
        "Recipient",
        "CalledNumber",
        "ToNumber",
        "MSISDN_B",
      ],
    },
    {
      name: "Start",
      required: true,
      description: "Call start date/time",
      aliases: ["StartTime", "Start_Time", "DateTime", "CallStart", "StartDateTime", "Timestamp", "Date", "Time"],
    },
    {
      name: "Call Duration",
      required: false,
      description: "Duration of call",
      aliases: ["Duration", "CallTime", "TalkTime", "Seconds", "CallLength", "DurationSec", "TotalDuration"],
    },
    {
      name: "Usage Type",
      required: false,
      description: "Type of service",
      aliases: ["ServiceType", "CallType", "UsageCategory", "Type", "Direction", "Service", "ActivityType"],
    },
    {
      name: "IMEI",
      required: false,
      description: "Device identifier (15 digits)",
      aliases: ["DeviceID", "Device_ID", "HandsetIMEI", "EquipmentID", "TAC"],
    },
    {
      name: "IMSI",
      required: false,
      description: "Subscriber identifier",
      aliases: ["SubscriberID", "Subscriber_ID", "SIM_ID", "SIMID", "SubscriberIdentity"],
    },
    {
      name: "LAC",
      required: false,
      description: "Location Area Code",
      aliases: ["LAC_ID", "LAC-ID", "LocationAreaCode", "AreaCode", "LA"],
    },
    {
      name: "Cell ID",
      required: false,
      description: "Cell tower identifier",
      aliases: ["CI", "CellIdentifier", "Cell_ID", "CID", "CGI", "CellSite", "TowerID"],
    },
    {
      name: "Bts Address",
      required: false,
      description: "Tower location/address",
      aliases: ["Address", "Location", "SiteAddress", "TowerAddress", "CellAddress", "SiteName", "BTSLocation"],
    },
    {
      name: "Latitude",
      required: false,
      description: "GPS latitude",
      aliases: ["Lat", "GPS_Lat", "GeoLat", "Y_Coord"],
    },
    {
      name: "Longitude",
      required: false,
      description: "GPS longitude",
      aliases: ["Long", "Lng", "GPS_Long", "GeoLong", "X_Coord"],
    },
  ],
  tower: [
    {
      name: "MSISDN",
      required: true,
      description: "Mobile number",
      aliases: ["PhoneNumber", "Phone", "Number", "Mobile", "MobileNumber"],
    },
    {
      name: "IMEI",
      required: false,
      description: "Device identifier",
      aliases: ["DeviceID", "Device_ID", "HandsetIMEI"],
    },
    {
      name: "IMSI",
      required: false,
      description: "Subscriber identifier",
      aliases: ["SubscriberID", "Subscriber_ID", "SIM_ID"],
    },
    {
      name: "DateTime",
      required: true,
      description: "Activity timestamp",
      aliases: ["Timestamp", "Date", "Time", "Start", "ActivityTime"],
    },
    {
      name: "LAC",
      required: true,
      description: "Location Area Code",
      aliases: ["LAC_ID", "LAC-ID", "LocationAreaCode"],
    },
    {
      name: "Cell ID",
      required: true,
      description: "Cell identifier",
      aliases: ["CI", "CellIdentifier", "Cell_ID", "CID"],
    },
  ],
}

// Synonym dictionary for intelligent matching
const SYNONYM_MAP: Record<string, string[]> = {
  operator: ["provider", "providername", "carrier", "telecomcompany", "network", "serviceprovider", "telco"],
  "party a": [
    "aparty",
    "a_party",
    "a-party",
    "caller",
    "source",
    "originator",
    "callingnumber",
    "fromnumber",
    "msisdn_a",
    "calling",
    "from",
  ],
  "party b": [
    "bparty",
    "b_party",
    "b-party",
    "called",
    "destination",
    "recipient",
    "callednumber",
    "tonumber",
    "msisdn_b",
    "to",
    "dialed",
  ],
  start: [
    "starttime",
    "start_time",
    "datetime",
    "callstart",
    "startdatetime",
    "timestamp",
    "date",
    "time",
    "calldate",
    "calltime",
  ],
  "call duration": [
    "duration",
    "calltime",
    "talktime",
    "seconds",
    "calllength",
    "durationsec",
    "totalduration",
    "length",
    "sec",
  ],
  "usage type": [
    "servicetype",
    "calltype",
    "usagecategory",
    "type",
    "direction",
    "service",
    "activitytype",
    "category",
  ],
  imei: ["deviceid", "device_id", "handsetimei", "equipmentid", "tac", "device", "handset"],
  imsi: ["subscriberid", "subscriber_id", "sim_id", "simid", "subscriberidentity", "sim"],
  lac: ["lac_id", "lac-id", "locationareacode", "areacode", "la", "location_area"],
  "cell id": ["ci", "cellidentifier", "cell_id", "cid", "cgi", "cellsite", "towerid", "cell", "cellno"],
  "bts address": [
    "address",
    "location",
    "siteaddress",
    "toweraddress",
    "celladdress",
    "sitename",
    "btslocation",
    "site",
    "tower",
  ],
  latitude: ["lat", "gps_lat", "geolat", "y_coord", "y"],
  longitude: ["long", "lng", "gps_long", "geolong", "x_coord", "x", "lon"],
  msisdn: ["phonenumber", "phone", "number", "mobile", "mobilenumber", "subscriber", "msisdn_no"],
}

// Pattern-based detection rules
const PATTERN_RULES: Array<{ pattern: RegExp; targetColumn: string; dataPattern?: RegExp }> = [
  { pattern: /^(start|begin|call).*(date|time)/i, targetColumn: "Start" },
  { pattern: /^(date|time|timestamp)/i, targetColumn: "Start" },
  { pattern: /(duration|length|seconds|sec)/i, targetColumn: "Call Duration" },
  { pattern: /^imei/i, targetColumn: "IMEI" },
  { pattern: /^imsi/i, targetColumn: "IMSI" },
  { pattern: /^(lac|location.*area)/i, targetColumn: "LAC" },
  { pattern: /^(cell|ci|cid|cgi)/i, targetColumn: "Cell ID" },
  { pattern: /(address|location|site|tower|bts)/i, targetColumn: "Bts Address" },
  { pattern: /^(lat|latitude)/i, targetColumn: "Latitude" },
  { pattern: /^(lon|lng|long|longitude)/i, targetColumn: "Longitude" },
  { pattern: /(operator|provider|carrier|network|telco)/i, targetColumn: "Operator" },
  { pattern: /(type|category|service|direction)/i, targetColumn: "Usage Type" },
]

// Data type detection based on sample values
export function detectDataType(values: string[]): ColumnMapping["dataType"] {
  const nonEmptyValues = values.filter((v) => v && v.trim() !== "").slice(0, 50)
  if (nonEmptyValues.length === 0) return "text"

  // Check for IMEI (15 digits)
  const imeiPattern = /^\d{15}$/
  if (nonEmptyValues.every((v) => imeiPattern.test(v.replace(/[-\s]/g, "")))) {
    return "imei"
  }

  // Check for IMSI (15 digits, often starts with country code)
  const imsiPattern = /^\d{15}$/
  if (nonEmptyValues.every((v) => imsiPattern.test(v.replace(/[-\s]/g, "")))) {
    return "imsi"
  }

  // Check for phone numbers (10-15 digits, may have + or country code)
  const phonePattern = /^[+]?[\d\s\-$$$$]{10,18}$/
  if (nonEmptyValues.filter((v) => phonePattern.test(v)).length > nonEmptyValues.length * 0.7) {
    return "phone"
  }

  // Check for dates
  const datePatterns = [
    /^\d{4}[-/]\d{2}[-/]\d{2}/, // YYYY-MM-DD
    /^\d{2}[-/]\d{2}[-/]\d{4}/, // DD-MM-YYYY
    /^\d{2}[-/]\d{2}[-/]\d{2}/, // DD-MM-YY
  ]
  if (nonEmptyValues.some((v) => datePatterns.some((p) => p.test(v)))) {
    return "date"
  }

  // Check for time
  const timePattern = /^\d{1,2}:\d{2}(:\d{2})?(\s*(AM|PM))?$/i
  if (nonEmptyValues.filter((v) => timePattern.test(v)).length > nonEmptyValues.length * 0.7) {
    return "time"
  }

  // Check for numbers
  const numberPattern = /^-?[\d,]+\.?\d*$/
  if (nonEmptyValues.filter((v) => numberPattern.test(v.replace(/,/g, ""))).length > nonEmptyValues.length * 0.8) {
    return "number"
  }

  return "text"
}

// Normalize column name for comparison
function normalizeColumnName(name: string): string {
  return name
    .toLowerCase()
    .replace(/[\s_\-.]+/g, " ")
    .replace(/[^a-z0-9\s]/g, "")
    .trim()
}

// Calculate string similarity (Levenshtein-based)
function calculateSimilarity(str1: string, str2: string): number {
  const s1 = str1.toLowerCase()
  const s2 = str2.toLowerCase()

  if (s1 === s2) return 1
  if (s1.length === 0 || s2.length === 0) return 0

  const matrix: number[][] = []

  for (let i = 0; i <= s1.length; i++) {
    matrix[i] = [i]
  }
  for (let j = 0; j <= s2.length; j++) {
    matrix[0][j] = j
  }

  for (let i = 1; i <= s1.length; i++) {
    for (let j = 1; j <= s2.length; j++) {
      const cost = s1[i - 1] === s2[j - 1] ? 0 : 1
      matrix[i][j] = Math.min(matrix[i - 1][j] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j - 1] + cost)
    }
  }

  const maxLen = Math.max(s1.length, s2.length)
  return 1 - matrix[s1.length][s2.length] / maxLen
}

// Main auto-mapping function
export function autoMapColumns(
  sourceColumns: string[],
  sampleData: Record<string, string>[],
  moduleType: "cdr" | "tower" = "cdr",
): ColumnMapping[] {
  const targetCols = TARGET_COLUMNS[moduleType]
  const mappings: ColumnMapping[] = []
  const usedTargets = new Set<string>()

  for (const sourceCol of sourceColumns) {
    const normalizedSource = normalizeColumnName(sourceCol)
    const sampleValues = sampleData.slice(0, 10).map((row) => row[sourceCol] || "")
    const dataType = detectDataType(sampleValues)

    let bestMatch: ColumnMapping = {
      sourceColumn: sourceCol,
      targetColumn: "",
      confidence: 0,
      matchType: "none",
      sampleData: sampleValues.slice(0, 3),
      dataType,
    }

    for (const target of targetCols) {
      if (usedTargets.has(target.name)) continue

      const normalizedTarget = normalizeColumnName(target.name)
      let confidence = 0
      let matchType: ColumnMapping["matchType"] = "none"

      // 1. Exact match (highest priority)
      if (normalizedSource === normalizedTarget) {
        confidence = 100
        matchType = "exact"
      }
      // 2. Synonym match
      else {
        const synonyms = SYNONYM_MAP[normalizedTarget] || []
        const allSynonyms = [
          normalizedTarget,
          ...synonyms,
          ...(target.aliases?.map((a) => normalizeColumnName(a)) || []),
        ]

        if (
          allSynonyms.some(
            (syn) => normalizedSource === syn || normalizedSource.includes(syn) || syn.includes(normalizedSource),
          )
        ) {
          confidence = 90
          matchType = "synonym"
        }
        // 3. Pattern match
        else {
          for (const rule of PATTERN_RULES) {
            if (rule.targetColumn === target.name && rule.pattern.test(sourceCol)) {
              confidence = 80
              matchType = "pattern"
              break
            }
          }
        }

        // 4. Fuzzy match
        if (matchType === "none") {
          const similarity = calculateSimilarity(normalizedSource, normalizedTarget)
          if (similarity > 0.7) {
            confidence = Math.round(similarity * 70)
            matchType = "fuzzy"
          }
        }
      }

      // Data type validation boost/penalty
      if (confidence > 0) {
        if (target.name === "IMEI" && dataType === "imei") confidence = Math.min(100, confidence + 10)
        if (target.name === "IMSI" && dataType === "imsi") confidence = Math.min(100, confidence + 10)
        if (target.name === "Start" && (dataType === "date" || dataType === "time"))
          confidence = Math.min(100, confidence + 5)
        if (target.name === "Call Duration" && dataType === "number") confidence = Math.min(100, confidence + 5)
        if ((target.name === "Party A" || target.name === "Party B") && dataType === "phone")
          confidence = Math.min(100, confidence + 5)
      }

      if (confidence > bestMatch.confidence) {
        bestMatch = {
          sourceColumn: sourceCol,
          targetColumn: target.name,
          confidence,
          matchType,
          sampleData: sampleValues.slice(0, 3),
          dataType,
        }
      }
    }

    if (bestMatch.confidence >= 50) {
      usedTargets.add(bestMatch.targetColumn)
    }

    mappings.push(bestMatch)
  }

  return mappings
}

// Validate mapped data
export function validateMappedData(
  data: Record<string, string>[],
  mappings: ColumnMapping[],
  moduleType: "cdr" | "tower" = "cdr",
): ValidationResult {
  const errors: ValidationError[] = []
  const warnings: ValidationWarning[] = []
  const targetCols = TARGET_COLUMNS[moduleType]

  // Check required columns
  const requiredCols = targetCols.filter((c) => c.required)
  for (const reqCol of requiredCols) {
    const mapping = mappings.find((m) => m.targetColumn === reqCol.name && m.confidence > 0)
    if (!mapping) {
      errors.push({
        column: reqCol.name,
        message: `Required column "${reqCol.name}" is not mapped`,
        severity: "error",
      })
    }
  }

  // Validate IMEI format
  const imeiMapping = mappings.find((m) => m.targetColumn === "IMEI" && m.confidence > 0)
  if (imeiMapping) {
    let invalidCount = 0
    data.forEach((row, idx) => {
      const val = row[imeiMapping.sourceColumn]?.replace(/[-\s]/g, "")
      if (val && !/^\d{15}$/.test(val)) {
        invalidCount++
        if (invalidCount <= 3) {
          errors.push({
            column: "IMEI",
            row: idx + 1,
            message: `Invalid IMEI format: "${val}" (must be 15 digits)`,
            severity: "warning",
          })
        }
      }
    })
    if (invalidCount > 3) {
      warnings.push({
        column: "IMEI",
        message: `${invalidCount} rows have invalid IMEI format`,
        affectedRows: invalidCount,
      })
    }
  }

  // Validate IMSI format
  const imsiMapping = mappings.find((m) => m.targetColumn === "IMSI" && m.confidence > 0)
  if (imsiMapping) {
    let invalidCount = 0
    data.forEach((row) => {
      const val = row[imsiMapping.sourceColumn]?.replace(/[-\s]/g, "")
      if (val && !/^\d{15}$/.test(val)) {
        invalidCount++
      }
    })
    if (invalidCount > 0) {
      warnings.push({
        column: "IMSI",
        message: `${invalidCount} rows have invalid IMSI format`,
        affectedRows: invalidCount,
      })
    }
  }

  // Check for duplicate mappings
  const targetCounts: Record<string, number> = {}
  mappings.forEach((m) => {
    if (m.targetColumn && m.confidence > 0) {
      targetCounts[m.targetColumn] = (targetCounts[m.targetColumn] || 0) + 1
    }
  })
  for (const [target, count] of Object.entries(targetCounts)) {
    if (count > 1) {
      errors.push({
        column: target,
        message: `Column "${target}" is mapped multiple times`,
        severity: "error",
      })
    }
  }

  return {
    isValid: errors.filter((e) => e.severity === "error").length === 0,
    errors,
    warnings,
  }
}

// Template management functions
export function saveMappingTemplate(
  template: Omit<MappingTemplate, "id" | "createdAt" | "updatedAt" | "usageCount">,
): MappingTemplate {
  const templates = getMappingTemplates()
  const newTemplate: MappingTemplate = {
    ...template,
    id: `template_${Date.now()}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    usageCount: 0,
  }
  templates.push(newTemplate)
  localStorage.setItem("rtf_mapping_templates", JSON.stringify(templates))
  return newTemplate
}

export function getMappingTemplates(): MappingTemplate[] {
  if (typeof window === "undefined") return []
  const stored = localStorage.getItem("rtf_mapping_templates")
  return stored ? JSON.parse(stored) : []
}

export function deleteTemplate(templateId: string): void {
  const templates = getMappingTemplates().filter((t) => t.id !== templateId)
  localStorage.setItem("rtf_mapping_templates", JSON.stringify(templates))
}

export function applyTemplate(templateId: string, sourceColumns: string[]): ColumnMapping[] | null {
  const templates = getMappingTemplates()
  const template = templates.find((t) => t.id === templateId)
  if (!template) return null

  // Update usage count
  template.usageCount++
  template.updatedAt = new Date().toISOString()
  localStorage.setItem("rtf_mapping_templates", JSON.stringify(templates))

  // Apply template mappings to current source columns
  return sourceColumns.map((sourceCol) => {
    const templateMapping = template.mappings.find(
      (m) => normalizeColumnName(m.sourceColumn) === normalizeColumnName(sourceCol),
    )
    if (templateMapping) {
      return {
        ...templateMapping,
        sourceColumn: sourceCol,
        matchType: "manual" as const,
      }
    }
    return {
      sourceColumn: sourceCol,
      targetColumn: "",
      confidence: 0,
      matchType: "none" as const,
    }
  })
}

// Find best matching template for given columns
export function suggestTemplate(sourceColumns: string[]): MappingTemplate | null {
  const templates = getMappingTemplates()
  let bestMatch: { template: MappingTemplate; score: number } | null = null

  for (const template of templates) {
    const templateCols = template.mappings.map((m) => normalizeColumnName(m.sourceColumn))
    const sourceCols = sourceColumns.map((c) => normalizeColumnName(c))

    let matchCount = 0
    for (const col of sourceCols) {
      if (templateCols.some((tc) => tc === col || calculateSimilarity(tc, col) > 0.8)) {
        matchCount++
      }
    }

    const score = matchCount / Math.max(templateCols.length, sourceCols.length)

    if (score > 0.5 && (!bestMatch || score > bestMatch.score)) {
      bestMatch = { template, score }
    }
  }

  return bestMatch?.template || null
}

// Apply mappings to transform data
export function applyMappingsToData(
  data: Record<string, string>[],
  mappings: ColumnMapping[],
): Record<string, string>[] {
  return data.map((row) => {
    const newRow: Record<string, string> = {}
    for (const mapping of mappings) {
      if (mapping.targetColumn && mapping.confidence > 0) {
        newRow[mapping.targetColumn] = row[mapping.sourceColumn] || ""
      }
    }
    // Keep unmapped columns with original names
    for (const key of Object.keys(row)) {
      const mapping = mappings.find((m) => m.sourceColumn === key)
      if (!mapping || mapping.confidence === 0 || !mapping.targetColumn) {
        newRow[key] = row[key]
      }
    }
    return newRow
  })
}
